from .region import CacheRegion, register_backend, make_region  # noqa

# backwards compat
from .. import __version__  # noqa
