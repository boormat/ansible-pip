=========================================
osc-lib -- OpenStackClient Plugin Library
=========================================

OpenStackClient (aka OSC) is a command-line client for OpenStack.  osc-lib
is a package of common support modules for writing OSC plugins.

Contents:

.. toctree::
   :maxdepth: 2

   user/index
   reference/index
   contributor/index

.. rubric:: Indices and tables

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
