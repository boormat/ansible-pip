This directory contains scripts meant to help configuring ARA with Ansible.

For more information, visit the documentation_.

.. _documentation: http://ara.readthedocs.io/en/latest/configuration.html
