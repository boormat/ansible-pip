XStatic
-------

The goal of XStatic family of packages is to provide static file packages
with minimal overhead - without selling you some dependencies you don't want.

XStatic has some minimal support code for working with the XStatic-* packages.

Docs: http://readthedocs.org/docs/xstatic/en/latest/

Repository: https://bitbucket.org/thomaswaldmann/xstatic

Licenses:

* MIT license (for XStatic code)
* same license as packaged file (for static file packages)

