# Copyright: 2011-2014 by the XStatic authors, see AUTHORS.txt for details.
# License: MIT license, see LICENSE.txt for details.

__import__('pkg_resources').declare_namespace(__name__)
