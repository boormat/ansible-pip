require 'puppet/util/network_device'

module Puppet::Util::NetworkDevice::Ilo
end
