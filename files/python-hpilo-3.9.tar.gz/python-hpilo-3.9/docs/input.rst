Keyboard and mouse settings
===========================


.. py:currentmodule:: hpilo

.. class:: Ilo
   :noindex:

   .. automethod:: get_hotkey_config
   .. ilo_output:: get_hotkey_config
   .. automethod:: hotkey_config
   .. automethod:: get_pers_mouse_keyboard_enabled
   .. ilo_output:: get_pers_mouse_keyboard_enabled
   .. automethod:: set_pers_mouse_keyboard_enabled
